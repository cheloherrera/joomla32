/*
htmLawed_README.txt, 3 July 2010
htmLawed 1.1.9.4, 3 July 2010
Copyright Santosh Patnaik
LGPL v3 license
A PHP Labware internal utility - http://www.bioinformatics.org/phplabware/internal_utilities/htmLawed
*/

Information is available at http://www.bioinformatics.org/phplabware/internal_utilities/htmLawed

@@description: htmLawed PHP software is a free, open-source, customizable HTML input purifier and filter
@@encoding: utf-8
@@keywords: htmLawed, HTM, HTML, HTML Tidy, converter, filter, formatter, purifier, sanitizer, XSS, input, PHP, software, code, script, security, cross-site scripting, hack, sanitize, remove, standards, tags, attributes, elements
@@language: en
@@title: htmLawed documentation